package com.rachel.rabbitmq;

import com.rachel.rabbitmq.dao.OrderDao;
import com.rachel.rabbitmq.dao.OrderPO;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
@org.springframework.amqp.rabbit.annotation.RabbitListener(queues = "order.dlx.queue")
public class RabbitListener {

    @Autowired
    private OrderDao orderDao;

    @RabbitHandler
    public void processDlxMessage(String message){
        System.out.println(message);
        try {
            final Optional<OrderPO> optional = orderDao.findById(Integer.parseInt(message));
            if (optional.isEmpty()) {
                return;
            }
            OrderPO order = optional.get();
            if (order.getStatus().equals("请在30秒之内支付订单!!!")) {
                order.setStatus("订单超时未支付");
                orderDao.save(order);
            }
        }catch (Exception e){
            System.out.println("接收消息出错");
        }
        return;
    }
}
