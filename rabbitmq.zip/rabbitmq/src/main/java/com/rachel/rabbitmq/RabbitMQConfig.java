package com.rachel.rabbitmq;

import org.springframework.amqp.core.*;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

@SpringBootApplication
@Configuration
public class RabbitMQConfig {

    @Bean
    public Queue queueTTLWaiting(){
        Map<String,Object> props = new HashMap<>();
        // 设置队列中消息过期时间
        props.put("x-message-ttl",30000);
//        props.put("x-expires", 30000);
        // 设置该队列所关联的死信交换器（当队列消息ttl到期后任然没有消费，则加入死信队列）
        props.put("x-dead-letter-exchange","order.dlx.exchange");
        // 设置该队列所关联的死信交换器的routingKey,如果没有特殊指定，使用原队列的routingKey
        props.put("x-dead-letter-routing-key","order.key");
        Queue queue = new Queue("order.queue", true, false, false, props);
        return queue;
    }

    @Bean
    public Exchange exchangeTTL(){
        final DirectExchange directExchange = new DirectExchange("order.ttl.exchange", true, false, null);
        return directExchange;
    }

    /**
     * 死信交换器
     * @return
     */
    @Bean
    public Exchange exchangeDlx(){
        DirectExchange exchange = new DirectExchange("order.dlx.exchange",true, false, null);
        return exchange;
    }

    @Bean
    public Queue queueDlx(){
        Queue queue = new Queue("order.dlx.queue", true, false, false);
        return queue;
    }


    @Bean
    public Binding bindingDlx(){
        return BindingBuilder.bind(queueDlx()).to(exchangeDlx()).with("order.key").noargs();
    }

    @Bean
    public Binding bindingTTL(){
        return BindingBuilder.bind(queueTTLWaiting()).to(exchangeTTL()).with("order.key").noargs();
    }
}
