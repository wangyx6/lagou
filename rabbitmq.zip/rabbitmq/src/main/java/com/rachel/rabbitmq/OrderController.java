package com.rachel.rabbitmq;

import com.rachel.rabbitmq.dao.OrderDao;
import com.rachel.rabbitmq.dao.OrderPO;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.core.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.Optional;

@RestController
@RequestMapping("/message")
public class OrderController {

    @Autowired
    private AmqpTemplate rabbitTemplate;

    @Autowired
    private OrderDao orderDao;

    @RequestMapping("/create")
    public String creatOrder(String name) {
        OrderPO orderPO = new OrderPO();
        orderPO.setName(name);
        orderPO.setPrice("30RMB");
        orderPO.setStatus("请在30秒之内支付订单!!!");
        orderPO.setOrderDate(new Date());
        orderDao.save(orderPO);
        rabbitTemplate.convertAndSend("order.ttl.exchange", "order.key", String.valueOf(orderPO.getId()));
        return orderPO.toString();
    }
    @RequestMapping("/pay")
    public String payOrder(Integer id) {
        Optional<OrderPO> optional = orderDao.findById(id);
        if(optional.isEmpty()){
            return "订单不存在";
        }
        if(optional.get().getStatus().equals("请在30秒之内支付订单!!!")){
            OrderPO orderPO = optional.get();
            orderPO.setStatus("已支付");
            orderDao.save(orderPO);
            return orderPO.toString();
        }
        return "订单支付超时!!";
    }

    @RequestMapping("/list")
    public String orderList(Integer id) {
        return orderDao.findAll().toString();
    }

}
