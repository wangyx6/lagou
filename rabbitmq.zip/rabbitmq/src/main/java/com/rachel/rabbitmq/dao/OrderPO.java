package com.rachel.rabbitmq.dao;

import lombok.Data;
import lombok.ToString;
import org.springframework.stereotype.Repository;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "da_order")
@Data
@ToString
public class OrderPO {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String name;

    private String price;

    private String status;

    private Date orderDate;
}
